# Student Attendance System
# Features:
# 1. Manage student details (ID, Name, Section, Course Code)
# 2. Track daily attendance (Present/Absent)
# 3. Display attendance for individual students or the entire class

class Student:
    def __init__(self, student_id, name, section, course_code):
        self.student_id = student_id
        self.name = name
        self.section = section
        self.course_code = course_code
        self.attendance = {}

    def mark_attendance(self, date, status):
        self.attendance[date] = status

    def get_attendance(self):
        return self.attendance


class AttendanceSystem:
    def __init__(self):
        self.students = {}

    def add_student(self, student_id, name, section, course_code):
        if student_id not in self.students:
            self.students[student_id] = Student(student_id, name, section, course_code)
            print(f"Student {name} has been added successfully.")
        else:
            print("Student ID already exists.")

    def mark_attendance(self, student_id, date, status):
        if student_id in self.students:
            self.students[student_id].mark_attendance(date, status)
            print(f"Attendance marked for {self.students[student_id].name} on {date}.")
        else:
            print("Student ID not found.")

    def view_individual_attendance(self, student_id):
        if student_id in self.students:
            student = self.students[student_id]
            print(f"\nAttendance Record for {student.name} ({student.section}, {student.course_code}):")
            if student.attendance:
                for date, status in student.attendance.items():
                    print(f"{date}: {status}")
            else:
                print("No attendance record found.")
        else:
            print("Student ID not found.")

    def view_all_attendance(self):
        print("\nComplete Attendance Record:")
        for student in self.students.values():
            print(f"\n{student.student_id} - {student.name} ({student.section}, {student.course_code})")
            if student.attendance:
                for date, status in student.attendance.items():
                    print(f"  {date}: {status}")
            else:
                print("  No attendance record found.")


# Main Program
def main():
    system = AttendanceSystem()

    while True:
        print("\n--- Student Attendance System ---")
        print("1. Add Student")
        print("2. Mark Attendance")
        print("3. View Individual Attendance")
        print("4. View All Attendance")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            student_id = input("Enter Student ID: ")
            name = input("Enter Student Name: ")
            section = input("Enter Section: ")
            course_code = input("Enter Course Code: ")
            system.add_student(student_id, name, section, course_code)

        elif choice == '2':
            student_id = input("Enter Student ID: ")
            date = input("Enter Date (YYYY-MM-DD): ")
            status = input("Enter Attendance (Present/Absent): ").capitalize()
            system.mark_attendance(student_id, date, status)

        elif choice == '3':
            student_id = input("Enter Student ID: ")
            system.view_individual_attendance(student_id)

        elif choice == '4':
            system.view_all_attendance()

        elif choice == '5':
            print("Exiting the program. Thank you!")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
